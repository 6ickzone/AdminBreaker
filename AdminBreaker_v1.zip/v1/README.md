# AdminBreaker v1

Dorking + Admin Panel Brute + SQLi Hunter CLI Tool.

**Developer:** 0x6ick
**Version:** v1
